from fastapi import FastAPI
from app.routes import router

app = FastAPI(title="Maize Nitrogen Detector API")

# Include routes
app.include_router(router)

@app.get("/")
def root():
    return {"message": "Welcome to the Maize Nitrogen Detector API!"}
