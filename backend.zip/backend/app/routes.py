from fastapi import APIRouter, UploadFile, HTTPException
from app.image_processor import process_images

router = APIRouter()

@router.post("/api/computeMaize/")
async def compute_maize(
    fullnitrogen1: UploadFile = None,
    fullnitrogen2: UploadFile = None,
    testimage1: UploadFile = None,
    testimage2: UploadFile = None
):
    if not (fullnitrogen1 and fullnitrogen2 and testimage1 and testimage2):
        raise HTTPException(status_code=400, detail="All images are required.")
    
    # Process images and return results
    result = process_images(fullnitrogen1, fullnitrogen2, testimage1, testimage2)
    return result

